package com.example.bombar_man

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
